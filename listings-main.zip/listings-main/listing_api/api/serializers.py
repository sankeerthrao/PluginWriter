from rest_framework import serializers
from .models import Item, Seller


class SellerPKAndPhoneField(serializers.Field):
    def to_representation(self, value):
        return {
            'id': value.id,
            'phone': value.phone
        }
        
class SellerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Seller
        fields = ['id', 'name', 'email', 'phone']


class ItemSerializer(serializers.ModelSerializer):
    #seller = SellerSerializer()
    #seller = serializers.PrimaryKeyRelatedField(queryset=Seller.objects.all())
    seller_info = SellerPKAndPhoneField(source='seller', read_only=True)
    seller = serializers.PrimaryKeyRelatedField(queryset=Seller.objects.all())

    class Meta:
        model = Item
        fields = ['id', 'name', 'location', 'category', 'url', 'seller', 'seller_info']
