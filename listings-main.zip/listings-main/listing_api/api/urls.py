from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('.well-known/', views.openai_plugin, name='home'),
    path('get_items/', views.ItemFilterView.as_view(), name='item-filter'),
    path('add_sellers/', views.SellerListCreate.as_view(), name='seller-list-create'),
    path('add_items/', views.ItemListCreate.as_view(), name='item-list-create'),

]
