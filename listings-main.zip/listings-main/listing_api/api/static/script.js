// const products = [
//     { id: 1, name: 'Smartphone', category: 'electronics', url: 'images/pexels-anne-985635.jpg'},
//     { id: 2, name: 'Laptop', category: 'electronics', url: 'images/pexels-elvis-2528118.jpg'},
//     { id: 3, name: 'T-Shirt', category: 'fashion', url: 'images/pexels-kai-pilger-996329.jpg' },
//     { id: 4, name: 'Sofa', category: 'home', url: 'images/pexels-martin-péchy-1866149.jpg'},
//     { id: 5, name: 'Sneakers', category: 'fashion', url: 'images/pexels-mnz-1598505.jpg'},
//     { id: 6, name: 'Television', category: 'electronics', url: 'images/pexels-cottonbro-studio-8059376.jpg'},
//     { id: 7, name: 'Dress', category: 'fashion', url: 'images/pexels-anne-985635.jpg'},
//     { id: 8, name: 'Coffee Table', category: 'home', url: 'images/pexels-brigitte-tohm-378006.jpg'},
// ];


function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      // Check if this cookie string begins with the name we want
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

const csrftoken = getCookie('csrftoken');

 async function fetchItems(location, item_name, category) {
  const queryParams = new URLSearchParams({
    location: location,
    item_name: item_name,
    category: category
  });
  const response =  await fetch(`http://104.208.64.252:8000/get_items/?${queryParams.toString()}`);
  console.log(response)
  const items =  await response.json();
  return items;
}

function renderProducts(filteredProducts) {
    console.log("testttttt", filteredProducts)
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    filteredProducts.forEach(product => {
        console.log("testttttt2222")
        const productDiv = document.createElement('div');
        productDiv.className = 'product';

        const productName = document.createElement('h3');
        productName.textContent = 'Title: '+product.name;
        productDiv.appendChild(productName);

        const productCategory = document.createElement('p');
        productCategory.textContent = 'Category: '+product.category;
        productDiv.appendChild(productCategory);

        const location = document.createElement('p');
        location.textContent = 'Location: '+product.location;
        productDiv.appendChild(location);

        const phone = document.createElement('p');
        phone.textContent = 'Contact: ' + product.seller_info.phone;
        productDiv.appendChild(phone);

        
        const img = document.createElement("img");
        img.src = product.url;
        img.alt = product.name ;
        img.style.width = '100%';
        productDiv.appendChild(img);

        productList.appendChild(productDiv);
        console.log(productList)

    });
}

// function filterProducts() {
//     const categoryFilter = document.getElementById('category-filter');
//     const selectedCategory = categoryFilter.value;

//     const filteredProducts = selectedCategory === 'all'
//         ? products
//         : products.filter(product => product.category === selectedCategory);

//     const items =  await fetchItems(location, item_name, );
//     renderProducts(filteredProducts);
// }

document.getElementById("filter-button").addEventListener("click", async () => {
  const location = document.getElementById("location-input").value;
  const item_name = document.getElementById("item-input").value;
  const categoryFilter = document.getElementById('category-filter').value;
  
  const items =  await fetchItems(location, item_name,categoryFilter);
  renderProducts(items);
});

//document.getElementById('category-filter').addEventListener('change', filterProducts);

// Initialize the product list

async function fetchAllItems() {
  const items = await fetchItems("", "", "");
  renderProducts(items);
}


document.getElementById("upload-form").addEventListener("submit", async (e) => {
    e.preventDefault(); // Prevent the default form submission behavior

    const name = document.getElementById("upload-name").value;
    const location = document.getElementById("upload-location").value;
    const category = document.getElementById("upload-category").value;
    // const url = document.getElementById("upload-url").value;

    const imageFile = document.getElementById("upload-image").files[0];

    

    try {
        // Upload image to Cloudinary
        let imageUrl = "";
        if (imageFile) {
          imageUrl = await uploadImageToCloudinary(imageFile);
        }
        console.log(imageUrl, "ooo")
        const phone = document.getElementById("upload-phone").value;

        const sellerData = {
           
            phone: phone,
        };

        // Create a new seller
        const sellerResponse = await fetch("http://104.208.64.252:8000/add_sellers/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrftoken,
            },
            body: JSON.stringify(sellerData),
        });

        if (sellerResponse.status === 201) {
            const seller = await sellerResponse.json();
            const itemData = {
                name: name,
                location: location,
                category: category,
                url: imageUrl,
                seller: seller.id,
            };

            // Create a new item with the created seller as a foreign key
            const itemResponse = await fetch("http://104.208.64.252:8000/add_items/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-CSRFToken": csrftoken,
                },
                body: JSON.stringify(itemData),
            });

            if (itemResponse.status === 201) {
                alert("Item uploaded successfully!");
                // Reload items or refresh the page to display the new item
            } else {
                alert("Failed to upload item. Please try again.");
            }
        } else {
            alert("Failed to create seller. Please try again.");
        }
    } catch (error) {
        console.error("Error uploading item:", error);
        alert("Failed to upload item. Please try again.");
    }
});

async function uploadImageToCloudinary(file) {
  const formData = new FormData();
  console.log("abc");
  formData.append("file", file);
  formData.append("upload_preset", "ml_default"); // Replace with your upload preset
  formData.append("api_key", "884694171796611"); // Replace with your API key

  console.log("abcd");
  const response = await fetch("https://api.cloudinary.com/v1_1/dsbcrzi36/image/upload", {
    method: "POST",
    body: formData,
  });
  console.log("abcde");

  if (response.ok) {
    const data = await response.json();
    return data.secure_url;
  } else {

        return response.json().then(error => {
            throw new Error(JSON.stringify(error));
        });
    
    throw new Error("Failed to upload image to Cloudinary");
  }
};

document.getElementById("post-item-button").addEventListener("click", function() {
    const uploadForm = document.getElementById("upload-form");
    uploadForm.style.display = "block";
});


fetchAllItems();
