from django.db import models
from django.utils.translation import gettext_lazy as _


# Create your models here.

from django.db import models

class Seller(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField(unique=True, blank=True, null=True)
    phone = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return f"Seller {str(self.id)}"

class ItemCategory(models.TextChoices):
    ELECTRONICS = 'electronics', _('Electronics')
    CLOTHES = 'clothes', _('Clothes')
    HOME = 'home', _('Home')
    BOOKS = 'books', _('Books')
    Furniture = 'furniture', _('Furniture')


class Item(models.Model):
    name = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    category = models.CharField(
        max_length=255,
        choices=ItemCategory.choices,
        default=ItemCategory.ELECTRONICS,
    )
    url = models.CharField(max_length=500, default="https://fastly.picsum.photos/id/0/5000/3333.jpg?hmac=_j6ghY5fCfSD6tvtcV74zXivkJSPIfR9B8w34XeQmvU")
    seller = models.ForeignKey(Seller, on_delete=models.CASCADE)


    def __str__(self):
        return self.name
