from rest_framework import status
from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

from rest_framework import generics
from rest_framework.response import Response
from .models import Item, Seller
from .serializers import ItemSerializer, SellerSerializer


def home(request):
    return render(request, 'home.html')

def openai_plugin(request):
    return render(request, "ai-plugin.json")

class ItemFilterView(generics.ListAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer

    def get_queryset(self):
        queryset = Item.objects.all()
        location = self.request.query_params.get('location', None)
        item_name = self.request.query_params.get('item_name', None)
        category = self.request.query_params.get('category', None)
        print (queryset, "1")

        if location is not None:
            queryset = queryset.filter(location__icontains=location)
        print (queryset, "2")
        if item_name is not None:
            queryset = queryset.filter(name__icontains=item_name)
        print (queryset, "3")
        if category is not None and category != 'all':
            queryset = queryset.filter(category__icontains=category)
        print (queryset, "4")
        return queryset

class SellerListCreate(generics.ListCreateAPIView):
    queryset = Seller.objects.all()
    serializer_class = SellerSerializer
    
    def create(self, request, *args, **kwargs):
        # Check if a seller with the same email or phone already exists
        phone = request.data.get('phone')
        existing_seller = Seller.objects.filter(phone=phone).first()
        try:
            print ('ttt')
            if existing_seller:
                print ('exist')
                # If a seller with the same email or phone exists, return that seller
                serializer = self.get_serializer(existing_seller)
            else:
                # If no existing seller is found, create a new seller
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            print (serializer.data, headers)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        except Exception as e:
            print (e)
class ItemListCreate(generics.ListCreateAPIView):
    print ('aaaaaa')
    try:
        queryset = Item.objects.all()
        serializer_class = ItemSerializer
        print ('bbb')
        def create(self, request, *args, **kwargs):
            serializer = self.get_serializer(data=request.data)
            print (request.data, "fff", serializer)
            serializer.is_valid(raise_exception=True)
            print ("ggg", serializer.validated_data)
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            print (serializer.data, "ccc")
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    except Exception as e:
            print (e)


